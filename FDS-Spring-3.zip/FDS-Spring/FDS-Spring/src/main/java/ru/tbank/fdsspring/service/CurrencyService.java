package ru.tbank.fdsspring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.tbank.fdsspring.model.Currency;
import ru.tbank.fdsspring.model.CurrencyRequest;
import ru.tbank.fdsspring.repository.CurrencyRepository;

import java.util.List;

@Service
public class CurrencyService {
    @Autowired
    private CurrencyRepository repository;

    public List<Currency> findAll() {
        return repository.findAll();
    }

    public Currency findById(Long id) {
        return repository.findById(id).orElseThrow(() -> new RuntimeException("Not found"));
    }

    public Currency create(CurrencyRequest request) {
        Currency currency = new Currency();
        currency.name = request.name;
        currency.baseCurrency = request.baseCurrency;
        currency.priceChangeRange = request.priceChangeRange;
        currency.description = request.description;
        return repository.save(currency);
    }

    public Currency update(Long id, CurrencyRequest request) {
        Currency currency = findById(id);
        currency.name = request.name;
        currency.baseCurrency = request.baseCurrency;
        currency.priceChangeRange = request.priceChangeRange;
        currency.description = request.description;
        return repository.save(currency);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }
}
