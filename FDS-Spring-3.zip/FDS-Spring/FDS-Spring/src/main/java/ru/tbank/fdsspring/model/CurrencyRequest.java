package ru.tbank.fdsspring.model;

public class CurrencyRequest {
    public String name;
    public String baseCurrency;
    public String priceChangeRange;
    public String description;
}
