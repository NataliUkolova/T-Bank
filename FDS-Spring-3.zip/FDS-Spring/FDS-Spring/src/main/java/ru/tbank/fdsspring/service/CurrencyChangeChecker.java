package ru.tbank.fdsspring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.tbank.fdsspring.dto.CbrCurrency;
import ru.tbank.fdsspring.model.Currency;

import java.util.List;
import java.util.Map;

@Service
public class CurrencyChangeChecker {

    @Autowired
    private CurrencyService currencyService;

    public void checkChanges(Map<String, CbrCurrency> remoteCurrencies) {
        List<Currency> dbCurrencies = currencyService.findAll();

        for (Currency currency : dbCurrencies) {
            CbrCurrency cbrCurrency = remoteCurrencies.get(currency.getBaseCurrency().toUpperCase());

            if (cbrCurrency != null) {
                double current = cbrCurrency.getValue();
                double previous = cbrCurrency.getPrevious();
                double change = ((current - previous) / previous) * 100;

                try {
                    String rangeStr = currency.getPriceChangeRange().replace("%", "").replace(",", ".");
                    double threshold = Double.parseDouble(rangeStr);
                    double roundedChange = Math.round(change * 100.0) / 100.0;

                    if ((threshold < 0 && change <= threshold) || (threshold > 0 && change >= threshold)) {
                        System.out.println("Уведомление: " + currency.getDescription());
                        System.out.printf(
                                "Валюта: %s (%s)\nТекущий курс: %.4f\nПредыдущий курс: %.4f\nИзменение: %.2f%% (порог: %s%%)\n\n",
                                currency.getName(),
                                currency.getBaseCurrency(),
                                current,
                                previous,
                                roundedChange,
                                threshold
                        );
                    }
                } catch (NumberFormatException e) {
                    System.err.println("Неверный формат priceChangeRange для " + currency.getName());
                }
            }
        }
    }
}

