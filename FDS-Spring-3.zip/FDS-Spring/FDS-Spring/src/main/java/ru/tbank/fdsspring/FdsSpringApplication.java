package ru.tbank.fdsspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.scheduling.annotation.EnableScheduling;
import ru.tbank.fdsspring.config.CbrConfig;

@SpringBootApplication
@EnableScheduling
@EnableConfigurationProperties(CbrConfig.class)
public class FdsSpringApplication {

    public static void main(String[] args) {
        SpringApplication.run(FdsSpringApplication.class, args);
    }

}
