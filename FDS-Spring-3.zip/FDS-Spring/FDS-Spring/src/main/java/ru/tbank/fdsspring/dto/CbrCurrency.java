package ru.tbank.fdsspring.dto;

import lombok.Data;

@Data
public class CbrCurrency {
    public String ID;
    public String NumCode;
    public String CharCode;
    public int Nominal;
    public String Name;
    public double Value;
    public double Previous;
}
