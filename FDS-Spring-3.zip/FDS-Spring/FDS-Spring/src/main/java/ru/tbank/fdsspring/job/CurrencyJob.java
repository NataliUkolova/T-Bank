package ru.tbank.fdsspring.job;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import ru.tbank.fdsspring.dto.CbrCurrency;
import ru.tbank.fdsspring.service.CbrClient;
import ru.tbank.fdsspring.service.CurrencyChangeChecker;
import java.util.Map;

@Service
public class CurrencyJob {

    @Autowired
    private CbrClient cbrClient;

    @Autowired
    private CurrencyChangeChecker changeChecker;

    @Scheduled(cron = "0 0 * * * *")
    public void checkCurrencyChanges() {
        try {
            Map<String, CbrCurrency> currencies = cbrClient.getCurrencies();
            changeChecker.checkChanges(currencies);
        } catch (Exception e) {
            System.err.println("Ошибка при выполнении проверки курсов: " + e.getMessage());
        }
    }
}

