package ru.tbank.fdsspring.service;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import ru.tbank.fdsspring.config.CbrConfig;
import ru.tbank.fdsspring.dto.CbrCurrency;
import ru.tbank.fdsspring.dto.CbrResponse;

import java.util.Map;

@RequiredArgsConstructor
@Service
public class CbrClient {
    private final RestTemplate restTemplate;
    private final CbrConfig cbrConfig;

    public Map<String, CbrCurrency> getCurrencies() {
        ResponseEntity<CbrResponse> response = restTemplate.getForEntity(cbrConfig.getUrl(), CbrResponse.class);
        if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
            return response.getBody().Valute;
        } else {
            throw new RuntimeException("Не удалось получить данные с ЦБ РФ");
        }
    }
}

