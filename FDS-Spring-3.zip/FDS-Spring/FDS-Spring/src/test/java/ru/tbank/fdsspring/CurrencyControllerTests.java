package ru.tbank.fdsspring;


import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.junit.jupiter.api.Test;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class CurrencyControllerTests {
    @Autowired
    private MockMvc mockMvc;

    @Test
    void testGetCurrencies() throws Exception {
        mockMvc.perform(get("/api/currencies"))
                .andExpect(status().isOk());
    }

    @Test
    void testAddCurrency() throws Exception {
        String json = "{\"name\":\"USD\",\"baseCurrency\":\"RUB\",\"priceChangeRange\":\"+10%/-10%\"}";
        mockMvc.perform(post("/api/currencies")
                        .contentType("application/json")
                        .content(json))
                .andExpect(status().isCreated());
    }

    @Test
    void testGetCurrency() throws Exception {
        mockMvc.perform(get("/api/currencies/1"))
                .andExpect(status().isOk());
    }

    @Test
    void testUpdateCurrency() throws Exception {
        String json = "{\"name\":\"EUR\",\"baseCurrency\":\"RUB\",\"priceChangeRange\":\"+5%/-5%\"}";
        mockMvc.perform(put("/api/currencies/1")
                        .contentType("application/json")
                        .content(json))
                .andExpect(status().isOk());
    }

    @Test
    void testDeleteCurrency() throws Exception {
        mockMvc.perform(delete("/api/currencies/1"))
                .andExpect(status().isNoContent());
    }
}
