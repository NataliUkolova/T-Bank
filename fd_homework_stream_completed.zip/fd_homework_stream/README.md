# StreamApiPractise

Задание в классе src/main/java/ru/gerch/streamPractise/service/CarService
